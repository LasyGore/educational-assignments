import os
import requests as rq
import logging

# Настраиваем логирование
logging.basicConfig(level=logging.INFO,
                    format='%(levelname)s: %(message)s',
                    handlers=[
                        logging.FileHandler('success_responses.log'),
                        logging.FileHandler('bad_responses.log'),
                        logging.FileHandler('blocked_responses.log')
                    ])

logger = logging.getLogger('RequestsLogger')

sites = ['https://www.youtube.com/', 'https://instagram.com', 'https://wikipedia.org', 'https://yahoo.com',
         'https://yandex.ru', 'https://whatsapp.com', 'https://twitter.com', 'https://amazon.com', 'https://tiktok.com',
         'https://www.ozon.ru']

for site in sites:
    try:
        response = rq.get(site, timeout=3)
        if response.status_code == 200:
            logger.info(f"'{site}', response - {response.status_code}")
        else:
            logger.warning(f"'{site}', response - {response.status_code}")
    except rq.exceptions.RequestException:
        logger.error(f"'{site}', NO CONNECTION")

# Определяем пути к файлам
success_file = 'success_responses.log'
bad_file = 'bad_responses.log'
blocked_file = 'blocked_responses.log'

# Функция для записи строк в файл
def write_to_file(filename, lines):
    with open(filename, 'w') as f:
        f.writelines(lines)

# Читаем содержимое файлов
with open('bad_responses.log', 'r') as f:
    all_lines = f.readlines()

# Фильтруем строки и записываем их в соответствующие файлы
success_lines = [line for line in all_lines if line.startswith('INFO:')]
bad_lines = [line for line in all_lines if line.startswith('WARNING:')]
blocked_lines = [line for line in all_lines if line.startswith('ERROR:')]

write_to_file(success_file, success_lines)
write_to_file(bad_file, bad_lines)
write_to_file(blocked_file, blocked_lines)

print("Файлы успешно созданы!")