import unittest
from main import Student

class TestStudent(unittest.TestCase):
    def test_walk(self):
        student = Student("Alice")
        for _ in range(10):
            student.walk()
        self.assertEqual(student.distance, 50, f"Дистанции не равны {student.distance} != 50")

    def test_run(self):
        student = Student("Bob")
        for _ in range(10):
            student.run()
        self.assertEqual(student.distance, 100, f"Дистанции не равны {student.distance} != 100")

    def test_competition(self):
        runner = Student("Charlie")
        walker = Student("David")
        for _ in range(10):
            runner.run()
        for _ in range(10):
            walker.walk()
        self.assertGreater(runner.distance, walker.distance, f"{runner} должен преодолеть дистанцию больше, чем {walker}")

if __name__ == '__main__':
    unittest.main()

#Мы импортируем unittest для использования стандартного фреймворка тестирования в Python,
#а также Student из модуля main.py.
#Создаем класс TestStudent, который наследуется от unittest.TestCase. Это позволяет нам использовать методы,
#предоставляемые TestCase, такие как assertEqual, assertGreater и assertLess.
#Каждый тест определяется как метод, начинающийся с test_.
#Это позволяет unittest автоматически находить и запускать тесты.
#В первом тесте test_walk мы создаем объект Student с именем "Alice", вызываем метод walk 10 раз, а затем проверяем,
#что расстояние, пройденное студентом, равно 50 с помощью assertEqual.
#Второй тест test_run аналогичен первому, но вместо walk мы вызываем run 10 раз и проверяем, что расстояние равно 100.
#В третьем тесте test_competition мы создаем двух студентов: "Charlie" (бегун) и "David" (ходок).
#Затем мы вызываем run 10 раз для "Charlie" и walk 10 раз для "David". Наконец, мы проверяем, что расстояние,
#пройденное "Charlie", больше, чем расстояние, пройденное "David", с помощью assertGreater.