import os
import requests
import pandas
import numpy
import numpy as np
import pandas as pd
import math
import matplotlib
import matplotlib.pyplot as plt
import PIL
from PIL import Image, ImageFilter
import PyPDF2
import pyttsx3

#OS (очистим экран, )

os.system('CLS')
os.system('COLOR 1e')
os.system('VER')

#requests
print('_____________________________1. Про requests')
r = requests.get('https://api.github.com/events')
print (r)

#pandas+
print('______________________________2. Про pandas')
d = {"a": 10, "b": 20, "c": 30, "g": 40}
print(pd.Series(d))
print()
print(pd.Series(d, index=["a", "b", "c", "d"]))

s = pd.Series(np.arange(5), index=["a", "b", "c", "d", "e"])
print("Выбор одного элемента")
print(s["a"])
print("Выбор нескольких элементов")
print(s[["a", "d"]])
print("Срез")
print(s[1:])
print("Поэлементное сложение")
print(s + s)

#numpy+
print('______________________________3. Про numpy')
print('Для примера создадим единичную матрицу ( с первого курса помню, еще на фортране создавал ;))))')
a = np.eye(5, 5, dtype="int8")
print(a)
print ('Поиграть с матрицами можно, например: ')
a = np.arange(1, 13).reshape(4, 3)
print(a)
print("Транспонирование")
print(a.transpose())
print("Поворот влево")
print(np.rot90(a))
print("Поворот вправо")
print(np.rot90(a, -1))

#matplotlib+
print('______________________________4. Про matplotlib')

# Линейная зависимость...

plt.plot([1,2,3,4])
plt.show()

#...и три синусоиды
t = np.arange(0,2.5,0.1)
y1 = np.sin(math.pi*t)
y2 = np.sin(math.pi*t+math.pi/2)
y3 = np.sin(math.pi*t-math.pi/2)
plt.plot(t,y1,'b*',t,y2,'g^',t,y3,'ys')
plt.show()

#pillow+
#посмотрим изображение, а потом...

print('_______________________________5. Про PIL')
try:
    original = Image.open("Lenna.png")
except FileNotFoundError:
    print("Файл не найден")
print("Размер изображения:")
print(original.format, original.size, original.mode)
original.thumbnail((800, 800))
original.show()

# ... например оконтурим изображение!

img = Image.open("Lenna.png")
img = img.filter(ImageFilter.CONTOUR)
img.save("LennaC" + ".jpg")
img.thumbnail((800, 800))
img.show()

# Небольшая вишенка на торте
#pdf_filename =input("Enter the PDF file name (including extension): ").strip()
print('______________________________6. Вишенка на торте')
pdf_filename ="EndLesson.pdf".strip()

# Open the PDF file
try:
    with open(pdf_filename, 'rb') as pdf_file:

        # Create a PdfFileReader object
        pdf_reader = PyPDF2.PdfReader(pdf_file)

        # Get an engine instance for the speech synthesis
        speak = pyttsx3.init()

        # Iterate through each page and read the text
        for page_num in range(len(pdf_reader.pages)):
            page = pdf_reader.pages[page_num]
            text = page.extract_text()
            if text:
                speak.say(text)
                speak.runAndWait()

        # Stop the speech engine
        speak.stop()
        print("Audiobook creation completed.")

except FileNotFoundError:
    print("The specified file was not found.")

except Exception as e:
    print(f"An error occurred: {e}")