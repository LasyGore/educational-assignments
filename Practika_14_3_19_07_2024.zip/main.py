#def write_holiday_cities(first_letter):
    # РЕАЛИЗАЦИЯ

#    pass

import csv


def write_holiday_cities(first_letter):
    cities_visited = set()
    cities_planned = set()

    with open('travel-notes.csv', 'r') as file:
        reader = csv.reader(file)
        for row in reader:
            name, visited_cities, planned_cities = row
            if name.startswith(first_letter):
                cities_visited.update(visited_cities.split(';'))
                cities_planned.update(planned_cities.split(';'))

    all_cities = cities_visited.union(cities_planned)
    cities_to_visit = cities_planned.difference(cities_visited)
    next_city = sorted(cities_to_visit)[0]

    with open('holiday.csv', 'w') as output_file:
        output_file.write("Посетили: " + ", ".join(sorted(cities_visited)) + "\n")
        output_file.write("Хотят посетить: " + ", ".join(sorted(cities_planned)) + "\n")
        output_file.write("Никогда не были в: " + ", ".join(sorted(cities_to_visit)) + "\n")
        output_file.write("Следующим городом будет: " + next_city)


# Запуск программы c подстановкой L, а затем R
write_holiday_cities('R')