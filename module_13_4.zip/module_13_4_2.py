from aiogram.dispatcher.filters.state import State, StatesGroup
from aiogram.contrib.fsm_storage.memory import MemoryStorage
class UserState(StatesGroup):
    age = State()
    growth = State()
    weight = State()

async def set_age(message):
    await message.answer("Введите свой возраст:")
    await UserState.age.set()

async def set_growth(message, state):
    await state.update_data(age=message.text)
    await message.answer("Введите свой рост:")
    await UserState.growth.set()

async def set_weight(message, state):
    await state.update_data(growth=message.text)
    await message.answer("Введите свой вес:")
    await UserState.weight.set()

async def send_calories(message, state):
    await state.update_data(weight=message.text)
    data = await state.get_data()
    age = int(data['age'])
    growth = int(data['growth'])
    weight = int(data['weight'])

    # Используем формулу Миффлин - Сан Жеора для подсчёта нормы калорий
    # В данном примере приведен расчет для мужчины
    bmr = 10 * weight + 6.25 * growth - 5 * age + 5
    await message.answer(f"Ваша норма калорий составляет {bmr} калорий в день.")
    await state.finish()

from aiogram import Bot, Dispatcher, executor, types

api = "xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx"
bot = Bot(token=api)
dp = Dispatcher(bot, storage=MemoryStorage())

# Настройка обработчиков
@dp.message_handler(text="Calories")
async def process_calories(message: types.Message):
    await set_age(message)

@dp.message_handler(state=UserState.age)
async def process_growth(message: types.Message, state: UserState):
    await set_growth(message, state)

@dp.message_handler(state=UserState.growth)
async def process_weight(message: types.Message, state: UserState):
    await set_weight(message, state)

@dp.message_handler(state=UserState.weight)
async def process_send_calories(message: types.Message, state: UserState):
    await send_calories(message, state)

if __name__ == '__main__':
    executor.start_polling(dp, skip_updates=True)