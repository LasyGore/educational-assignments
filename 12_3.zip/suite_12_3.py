import unittest
from test_12_1 import RunnerTest
from test_12_2_1 import TournamentTest

# Создаем объект TestSuite
def suite_maker():
    suite = unittest.TestSuite()

    # Добавляем тесты RunnerTest и TournamentTest
    suite.addTest(RunnerTest('test_walk'))
    suite.addTest(RunnerTest('test_run'))
    suite.addTest(RunnerTest('test_challenge'))
    suite.addTest(TournamentTest('test_usain_and_nick'))
    suite.addTest(TournamentTest('test_andrey_and_nick'))
    suite.addTest(TournamentTest('test_usain_and_andrey_and_nick'))

    return suite

# Создаем объект класса TextTestRunner с verbosity = 2
runner = unittest.TextTestRunner(verbosity=2)

# Пропуск тестов
class FrozenTestDecorator:
    def __init__(self, is_frozen):
        self.is_frozen = is_frozen

    def __call__(self, func):
        def wrapper(*args, **kwargs):
            if self.is_frozen:
                print(f"Test {func.__name__} is frozen")
                return
            else:
                return func(*args, **kwargs)
        return wrapper

# Атрибуты is_frozen
RunnerTest.is_frozen = False
TournamentTest.is_frozen = True

# Применяем декоратор к методам тестирования
for name, member in RunnerTest.__dict__.items():
    if callable(member) and name.startswith('test'):
        setattr(RunnerTest, name, FrozenTestDecorator(RunnerTest.is_frozen)(member))

for name, member in TournamentTest.__dict__.items():
    if callable(member) and name.startswith('test'):
        setattr(TournamentTest, name, FrozenTestDecorator(TournamentTest.is_frozen)(member))

# Запускаем тесты
if __name__ == '__main__':
    suite = suite_maker()
    runner.run(suite)