#Цель: Выбрать любую тему, которая вам больше нравится. Разобраться в теме. Понять, что от вас требуется по краткому
#описанию. Научиться находить и применять информацию из разных источников
#Deadline: неделя (до конца следующей недели 07.07.24)
#В процессе реализации, вы можете также использовать и другие библиотеки.
#ОБЯЗАТЕЛЬНО! Код выгрузить на github и прислать ссылку в этот чат

import tkinter as tk
from tkinter import messagebox
import random
import string

def generate_password():
    length = int(entry_length.get())
    num_upper = int(entry_upper.get())
    num_lower = int(entry_lower.get())
    num_special = int(entry_special.get())
    num_digits = int(entry_digits.get())

    if length < 2 or num_upper < 2 or num_lower < 2 or num_special < 2 or num_digits < 2:
        messagebox.showerror("ERROR", "Пожалуйста, введите не менее 2 символов для каждого поля")
    elif length != num_upper + num_lower + num_special + num_digits:
        messagebox.showerror("ERROR", "Сумма символов не равна общей длине пароля")
    else:
        upper_chars = ''.join(random.choices(string.ascii_uppercase, k=num_upper))
        lower_chars = ''.join(random.choices(string.ascii_lowercase, k=num_lower))
        special_chars = ''.join(random.choices(string.punctuation, k=num_special))
        digit_chars = ''.join(random.choices(string.digits, k=num_digits))

        generated_password = upper_chars + lower_chars + special_chars + digit_chars
        generated_password = ''.join(random.sample(generated_password, len(generated_password)))
        password_var.set(generated_password)

def clear_screen():
    entry_length.delete(0, tk.END)
    entry_upper.delete(0, tk.END)
    entry_lower.delete(0, tk.END)
    entry_special.delete(0, tk.END)
    entry_digits.delete(0, tk.END)
    password_var.set("")

def exit_app():
    root.destroy()

# Создание графического интерфейса
root = tk.Tk()
root.title("Генератор безопасного пароля")
root.geometry("800x600")

label_length = tk.Label(root, text="Длина пароля:")
label_length.pack()
entry_length = tk.Entry(root)
entry_length.pack()

label_upper = tk.Label(root, text="Кол-во заглавных букв:")
label_upper.pack()
entry_upper = tk.Entry(root)
entry_upper.pack()

label_lower = tk.Label(root, text="Кол-во строчных букв:")
label_lower.pack()
entry_lower = tk.Entry(root)
entry_lower.pack()

label_special = tk.Label(root, text="Кол-во спецсимволов:")
label_special.pack()
entry_special = tk.Entry(root)
entry_special.pack()

label_digits = tk.Label(root, text="Кол-во цифр:")
label_digits.pack()
entry_digits = tk.Entry(root)
entry_digits.pack()

button_generate = tk.Button(root, text="Готово", command=generate_password)
button_generate.pack()

button_clear = tk.Button(root, text="Очистить экран", command=clear_screen)
button_clear.pack()

button_exit = tk.Button(root, text="Выход", command=exit_app)
button_exit.pack()

password_var = tk.StringVar()
label_generated_password = tk.Label(root, font=("Arial", 48), textvariable=password_var, background="#FFCDD2", foreground="#B71C1C")
label_generated_password.pack()

root.mainloop()
