#Цель: Выбрать любую тему, которая вам больше нравится. Разобраться в теме. Понять, что от вас требуется по краткому
#описанию. Научиться находить и применять информацию из разных источников
#Deadline: неделя (до конца следующей недели 07.07.24)
#В процессе реализации, вы можете также использовать и другие библиотеки.
#ОБЯЗАТЕЛЬНО! Код выгрузить на github и прислать ссылку в этот чат

import tkinter as tk
from tkinter import messagebox
import qrcode
import os

class QRCodeGenerator:
    def __init__(self, root):
        self.root = root
        self.root.title("Генератор QR-кода на 128 знаков")
        self.root.geometry("800x600")

        self.label_input = tk.Label(self.root, text="Введите текст или URL:")
        self.label_input.pack()

        self.entry_text = tk.Entry(self.root, width=128)
        self.entry_text.pack()

        self.button_generate = tk.Button(self.root, text="Получить QR-код", command=self.generate_qr)
        self.button_generate.pack()

        self.button_clear = tk.Button(self.root, text="Очистить поле", command=self.clear_field)
        self.button_clear.pack()

        self.button_exit = tk.Button(self.root, text="Выход", command=self.exit_app)
        self.button_exit.pack()

    def generate_qr(self):
        text = self.entry_text.get()
        if not text:
            messagebox.showerror("Ошибка", "Пожалуйста, введите текст или URL для генерации QR-кода")
            return

        qr = qrcode.QRCode(
            version=1,
            error_correction=qrcode.constants.ERROR_CORRECT_L,
            box_size=10,
            border=4,
        )

        qr.add_data(text)
        qr.make(fit=True)

        img = qr.make_image(fill_color="black", back_color="white")

        # Сохранение QR-кода в файл с порядковым номером
        filename = f"{self.get_next_filename()}.jpg"
        img.save(filename)

        # Отображение сгенерированного QR-кода
        img.show()

    def clear_field(self):
        self.entry_text.delete(0, tk.END)

    def exit_app(self):
        self.root.destroy()

    def get_next_filename(self):
        # Получение порядкового номера для файла
        files = [f for f in os.listdir() if f.endswith('.jpg')]
        if files:
            last_file = max(files, key=lambda f: int(f.split('.')[0]))
            number = int(last_file.split('.')[0]) + 1
        else:
            number = 0
        return f"{number:08d}"

if __name__ == "__main__":
    root = tk.Tk()
    app = QRCodeGenerator(root)
    root.mainloop()