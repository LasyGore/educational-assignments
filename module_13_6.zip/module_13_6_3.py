from aiogram import Bot, Dispatcher, executor, types
from aiogram.dispatcher.filters.state import State, StatesGroup
from aiogram.contrib.fsm_storage.memory import MemoryStorage

class UserState(StatesGroup):
    age = State()
    growth = State()
    weight = State()

async def set_age(call):
    await call.message.answer("Введите свой возраст:")
    await UserState.age.set()

async def set_growth(message, state):
    await state.update_data(age=message.text)
    await message.answer("Введите свой рост:")
    await UserState.growth.set()

async def set_weight(message, state):
    await state.update_data(growth=message.text)
    await message.answer("Введите свой вес:")
    await UserState.weight.set()

async def send_calories(message, state):
    await state.update_data(weight=message.text)
    data = await state.get_data()
    age = int(data['age'])
    growth = int(data['growth'])
    weight = int(data['weight'])

    # Calculate BMR using Mifflin-St Jeor equation
    bmr = 10 * weight + 6.25 * growth - 5 * age + 5
    await message.answer(f"Ваша норма калорий составляет {bmr} калорий в день.")
    await state.finish()

def generate_inline_keyboard():
    keyboard = types.InlineKeyboardMarkup()
    button_calculate = types.InlineKeyboardButton('Рассчитать норму калорий', callback_data='calories')
    button_formulas = types.InlineKeyboardButton('Формулы расчёта', callback_data='formulas')
    keyboard.add(button_calculate, button_formulas)
    return keyboard

async def main_menu(message):
    keyboard = types.ReplyKeyboardMarkup(resize_keyboard=True)
    button_calculate = types.KeyboardButton('Рассчитать')
    button_info = types.KeyboardButton('Информация')
    keyboard.add(button_calculate, button_info)
    await message.answer("Выберите действие:", reply_markup=keyboard)

async def get_formulas(call):
    if call.data == 'formulas':
        formula_text = 'Формула Mifflin-St Jeor для мужчин: 10 * вес + 6.25 * рост - 5 * возраст + 5'
        await call.message.answer(formula_text)

if __name__ == "__main__":
    api_token = "ffffffffffffffffffffffffffffffffffffffffffffffffffffff"
    bot = Bot(token=api_token)
    storage = MemoryStorage()
    dp = Dispatcher(bot, storage=storage)

    @dp.message_handler(commands=['start'])
    async def start(message: types.Message):
        await main_menu(message)

    @dp.message_handler(text="Рассчитать")
    async def process_calculate(message: types.Message):
        keyboard = generate_inline_keyboard()
        await message.answer("Выберите опцию:", reply_markup=keyboard)

    @dp.callback_query_handler(text='calories')
    async def process_calculate_inline(call: types.CallbackQuery):
        await set_age(call)

    @dp.message_handler(state=UserState.age)
    async def process_growth(message: types.Message, state: UserState):
        await set_growth(message, state)

    @dp.message_handler(state=UserState.growth)
    async def process_weight(message: types.Message, state: UserState):
        await set_weight(message, state)

    @dp.message_handler(state=UserState.weight)
    async def process_send_calories(message: types.Message, state: UserState):
        await send_calories(message, state)

    @dp.callback_query_handler()
    async def callback_handler(call: types.CallbackQuery):
        await get_formulas(call)

    executor.start_polling(dp, skip_updates=True)