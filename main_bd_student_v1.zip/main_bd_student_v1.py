# -*- coding: utf-8 -*-
import os
import csv

os.system('CLS')
os.system('COLOR 1e')
os.system('VER')

def input_data():
    with open('userdata.csv', 'a', newline='') as file:
        writer = csv.writer(file, delimiter=';')
        os.system('CLS')
        while True:
            last_name = input("Введите фамилию: ")
            first_name = input("Введите имя: ")
            middle_name = input("Введите отчество: ")
            unique_number = input("Ведите выданный табельный номер: ")
            password = input("Введите пароль к аккаунту: ")
            email = input("Введите личный email: ")
            gender = input("Введите пол ( m если male или f если female): ")
            if gender == 'm' or gender == 'f':
                print("Вы ввели:", gender)
            else:
                print('Значение должно быть "m" или "f". Повторите ввод без ошибки!')
                continue
            age = int(input("Введите возраст: "))
            if age < 18:
                print("Возраст должен быть больше 18. Повторите ввод без ошибки.")
                continue
            writer.writerow([last_name, first_name, middle_name, unique_number, password, email, gender, age])
            print("Данные успешно записаны.")
            break

def view_data():
    with open('userdata.csv', 'r') as file:
        reader = csv.reader(file, delimiter=';')
        print('\n')
        for row in reader:
            print(row)

def main():
    while True:
        print("\n1. Ввод данных с консоли.")
        print("2. Просмотр данных в консоли.")
        print("3. Редактирование и проверка данных во внешней программе.")
        print("4. Выход.")
        choice = input("Выберите действие: ")
        os.system('CLS')
        if choice == '1':
            input_data()
        elif choice == '2':
            view_data()
        elif choice == '3':
            cmd = r'notepad.exe userdata.csv'
            os.system(cmd)
        elif choice == '4':
            print("\n**+** Всего доброго! **+**")
            break
        else:
            print("Неверный выбор. Попробуйте еще раз.")

if __name__ == "__main__":
    main()




